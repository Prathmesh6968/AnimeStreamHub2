import { Link } from 'react-router-dom';
import { Star, Play } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { Anime } from '@/types';
import { cn } from '@/lib/utils';

interface AnimeCardProps {
  anime: Anime;
  className?: string;
}

export function AnimeCard({ anime, className }: AnimeCardProps) {
  return (
    <Link to={`/anime/${anime.id}`}>
      <Card className={cn(
        "group overflow-hidden transition-all duration-300 hover:shadow-glow hover:scale-105",
        className
      )}>
        <div className="relative aspect-[2/3] overflow-hidden">
          <img
            src={anime.thumbnail_url || 'https://placehold.co/300x450/1a202c/6b46c1?text=No+Image'}
            alt={anime.title}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="absolute bottom-0 left-0 right-0 p-4">
              <div className="flex items-center gap-2 text-white">
                <Play className="w-5 h-5" />
                <span className="text-sm font-medium">Watch Now</span>
              </div>
            </div>
          </div>
          {anime.status === 'Ongoing' && (
            <Badge className="absolute top-2 right-2 bg-accent text-accent-foreground">
              Ongoing
            </Badge>
          )}
        </div>
        <CardContent className="p-4">
          <h3 className="font-semibold text-base line-clamp-1 mb-2">
            {anime.title}
          </h3>
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 fill-accent text-accent" />
              <span>{anime.rating?.toFixed(1) || 'N/A'}</span>
            </div>
            <span>{anime.release_year || 'TBA'}</span>
          </div>
          {anime.genres && anime.genres.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {anime.genres.slice(0, 2).map((genre) => (
                <Badge key={genre} variant="secondary" className="text-xs">
                  {genre}
                </Badge>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </Link>
  );
}
