import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { AnimeCard } from '@/components/anime/AnimeCard';
import { FilterSidebar } from '@/components/anime/FilterSidebar';
import { animeApi } from '@/db/api';
import type { Anime } from '@/types';
import { Search } from 'lucide-react';
import { useDebounce } from '@/hooks/use-debounce';

export default function Browse() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [anime, setAnime] = useState<Anime[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState(searchParams.get('search') || '');
  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);
  const [selectedStatus, setSelectedStatus] = useState(searchParams.get('status') || 'all');
  const [selectedYear, setSelectedYear] = useState('all');

  const debouncedSearch = useDebounce(searchQuery, 500);

  useEffect(() => {
    const loadAnime = async () => {
      setLoading(true);
      try {
        const filters: any = {};
        
        if (debouncedSearch) {
          filters.search = debouncedSearch;
        }
        
        if (selectedGenres.length > 0) {
          filters.genres = selectedGenres;
        }
        
        if (selectedStatus !== 'all') {
          filters.status = selectedStatus;
        }
        
        if (selectedYear !== 'all') {
          filters.year = Number.parseInt(selectedYear);
        }

        const data = await animeApi.getAll(filters);
        setAnime(data);
      } catch (error) {
        console.error('Error loading anime:', error);
      } finally {
        setLoading(false);
      }
    };

    loadAnime();
  }, [debouncedSearch, selectedGenres, selectedStatus, selectedYear]);

  const handleSearchChange = (value: string) => {
    setSearchQuery(value);
    if (value) {
      setSearchParams({ search: value });
    } else {
      setSearchParams({});
    }
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="container mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4">Browse Anime</h1>
          <div className="relative max-w-xl">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search anime..."
              value={searchQuery}
              onChange={(e) => handleSearchChange(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-[280px_1fr] gap-8">
          <aside className="hidden xl:block">
            <FilterSidebar
              selectedGenres={selectedGenres}
              onGenresChange={setSelectedGenres}
              selectedStatus={selectedStatus}
              onStatusChange={setSelectedStatus}
              selectedYear={selectedYear}
              onYearChange={setSelectedYear}
            />
          </aside>

          <main>
            {loading ? (
              <div className="grid grid-cols-2 xl:grid-cols-4 gap-6">
                {Array.from({ length: 12 }).map((_, i) => (
                  <div key={i} className="space-y-3">
                    <Skeleton className="aspect-[2/3] w-full bg-muted" />
                    <Skeleton className="h-4 w-3/4 bg-muted" />
                    <Skeleton className="h-3 w-1/2 bg-muted" />
                  </div>
                ))}
              </div>
            ) : anime.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-xl text-muted-foreground">
                  No anime found matching your criteria
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-2 xl:grid-cols-4 gap-6">
                {anime.map((item) => (
                  <AnimeCard key={item.id} anime={item} />
                ))}
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
