import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { AnimeCard } from '@/components/anime/AnimeCard';
import { animeApi } from '@/db/api';
import type { Anime } from '@/types';
import { ArrowRight, TrendingUp, Star } from 'lucide-react';

export default function Home() {
  const [featured, setFeatured] = useState<Anime[]>([]);
  const [trending, setTrending] = useState<Anime[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [featuredData, trendingData] = await Promise.all([
          animeApi.getFeatured(6),
          animeApi.getTrending(12)
        ]);
        setFeatured(featuredData);
        setTrending(trendingData);
      } catch (error) {
        console.error('Error loading anime:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  return (
    <div className="min-h-screen">
      <section className="relative py-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-transparent to-accent/20 pointer-events-none" />
        <div className="container mx-auto text-center relative z-10">
          <h1 className="text-5xl xl:text-7xl font-bold mb-6 gradient-text">
            Welcome to AnimeStream Hub
          </h1>
          <p className="text-xl xl:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Discover, watch, and track your favorite anime series all in one place
          </p>
          <div className="flex flex-col xl:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="text-lg">
              <Link to="/browse">
                Browse Anime
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="text-lg">
              <Link to="/watchlist">My Watchlist</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 px-4">
        <div className="container mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <Star className="w-6 h-6 text-accent" />
              <h2 className="text-3xl font-bold">Featured Anime</h2>
            </div>
            <Button asChild variant="ghost">
              <Link to="/browse">
                View All
                <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </Button>
          </div>
          {loading ? (
            <div className="grid grid-cols-2 xl:grid-cols-6 gap-6">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="space-y-3">
                  <Skeleton className="aspect-[2/3] w-full bg-muted" />
                  <Skeleton className="h-4 w-3/4 bg-muted" />
                  <Skeleton className="h-3 w-1/2 bg-muted" />
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 xl:grid-cols-6 gap-6">
              {featured.map((anime) => (
                <AnimeCard key={anime.id} anime={anime} />
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="py-12 px-4 bg-muted/30">
        <div className="container mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <TrendingUp className="w-6 h-6 text-accent" />
              <h2 className="text-3xl font-bold">Trending Now</h2>
            </div>
            <Button asChild variant="ghost">
              <Link to="/browse?status=Ongoing">
                View All
                <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </Button>
          </div>
          {loading ? (
            <div className="grid grid-cols-2 xl:grid-cols-6 gap-6">
              {Array.from({ length: 12 }).map((_, i) => (
                <div key={i} className="space-y-3">
                  <Skeleton className="aspect-[2/3] w-full bg-muted" />
                  <Skeleton className="h-4 w-3/4 bg-muted" />
                  <Skeleton className="h-3 w-1/2 bg-muted" />
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 xl:grid-cols-6 gap-6">
              {trending.map((anime) => (
                <AnimeCard key={anime.id} anime={anime} />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
