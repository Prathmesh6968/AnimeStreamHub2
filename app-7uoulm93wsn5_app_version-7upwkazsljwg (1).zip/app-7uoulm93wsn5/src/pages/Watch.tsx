import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { EpisodeList } from '@/components/anime/EpisodeList';
import { episodeApi, animeApi, progressApi } from '@/db/api';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import type { Episode, Anime, EpisodeWithProgress } from '@/types';
import { ArrowLeft } from 'lucide-react';

export default function Watch() {
  const { episodeId } = useParams<{ episodeId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();

  const [episode, setEpisode] = useState<Episode | null>(null);
  const [anime, setAnime] = useState<Anime | null>(null);
  const [episodes, setEpisodes] = useState<EpisodeWithProgress[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!episodeId) return;

    const loadData = async () => {
      try {
        const episodeData = await episodeApi.getById(episodeId);
        if (!episodeData) {
          toast({
            title: 'Error',
            description: 'Episode not found',
            variant: 'destructive'
          });
          navigate('/browse');
          return;
        }

        setEpisode(episodeData);

        const [animeData, episodesData] = await Promise.all([
          animeApi.getById(episodeData.anime_id),
          episodeApi.getByAnimeId(episodeData.anime_id)
        ]);

        setAnime(animeData);

        if (user) {
          const progressData = await progressApi.getByUserId(user.id, episodeData.anime_id);
          const progressMap = new Map(progressData.map(p => [p.episode_id, p]));

          const episodesWithProgress = episodesData.map(ep => ({
            ...ep,
            watched: progressMap.get(ep.id)?.watched || false,
            last_position: progressMap.get(ep.id)?.last_position || 0
          }));

          setEpisodes(episodesWithProgress);
        } else {
          setEpisodes(episodesData);
        }
      } catch (error) {
        console.error('Error loading episode:', error);
        toast({
          title: 'Error',
          description: 'Failed to load episode',
          variant: 'destructive'
        });
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [episodeId, user]);

  const handleEpisodeSelect = (newEpisodeId: string) => {
    navigate(`/watch/${newEpisodeId}`);
  };

  const handleMarkWatched = async (epId: string, watched: boolean) => {
    if (!user || !anime) return;

    try {
      await progressApi.markWatched(user.id, epId, anime.id, watched);
      
      setEpisodes(prev =>
        prev.map(ep =>
          ep.id === epId ? { ...ep, watched } : ep
        )
      );

      toast({
        title: watched ? 'Marked as watched' : 'Marked as unwatched'
      });
    } catch (error) {
      console.error('Error updating progress:', error);
      toast({
        title: 'Error',
        description: 'Failed to update progress',
        variant: 'destructive'
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen py-8 px-4">
        <div className="container mx-auto">
          <Skeleton className="aspect-video w-full mb-8 bg-muted" />
          <Skeleton className="h-8 w-1/3 mb-4 bg-muted" />
        </div>
      </div>
    );
  }

  if (!episode || !anime) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Episode not found</h2>
          <Button onClick={() => navigate('/browse')}>
            Browse Anime
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="container mx-auto">
        <Button
          variant="ghost"
          onClick={() => navigate(`/anime/${anime.id}`)}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to {anime.title}
        </Button>

        <div className="grid grid-cols-1 xl:grid-cols-[1fr_350px] gap-8">
          <div>
            <div className="aspect-video bg-black rounded-lg overflow-hidden mb-4">
              <iframe
                src={episode.video_url}
                className="w-full h-full"
                allowFullScreen
                title={`Episode ${episode.episode_number}`}
              />
            </div>
            <div className="space-y-2">
              <h1 className="text-2xl font-bold">
                {anime.title} - Episode {episode.episode_number}
              </h1>
              {episode.title && (
                <h2 className="text-xl text-muted-foreground">
                  {episode.title}
                </h2>
              )}
              {episode.description && (
                <p className="text-muted-foreground mt-4">
                  {episode.description}
                </p>
              )}
            </div>
          </div>

          <div>
            <EpisodeList
              episodes={episodes}
              currentEpisodeId={episode.id}
              onEpisodeSelect={handleEpisodeSelect}
              onMarkWatched={user ? handleMarkWatched : undefined}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
